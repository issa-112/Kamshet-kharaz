CREATE TABLE visitors (
    id SERIAL PRIMARY KEY,
    visit_date DATE DEFAULT CURRENT_DATE,
    ip_address VARCHAR(45),
    created_at TIMESTAMP DEFAULT NOW()
);