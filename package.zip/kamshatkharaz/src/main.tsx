import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import { ErrorBoundary } from './components/ErrorBoundary.tsx'
import './index.css'
import App from './App.tsx'

// إزالة العلامة المائية
const removeWatermark = () => {
  const keywords = ['minimax', 'created by', 'built by', 'made with', 'powered by'];
  const elements = document.querySelectorAll('*:not(script):not(style):not(title):not(meta)');
  
  elements.forEach((el) => {
    const text = el.textContent?.toLowerCase() || '';
    const hasKeyword = keywords.some(keyword => text.includes(keyword));
    
    if (hasKeyword && el.children.length === 0) {
      // تحقق من أن العنصر ليس جزء من المحتوى الرئيسي
      const isMainContent = el.closest('main, #root > div, [class*="container"]');
      if (!isMainContent) {
        (el as HTMLElement).style.display = 'none';
      }
    }
  });
  
  // إزالة العناصر بناءً على السمات
  const selectors = [
    '[data-attribution]',
    '[data-branding]',
    '[class*="attribution"]',
    '[class*="branding"]',
    '[class*="watermark"]',
    '[id*="attribution"]',
    '[id*="branding"]',
    '[id*="watermark"]'
  ];
  
  selectors.forEach(selector => {
    document.querySelectorAll(selector).forEach(el => {
      (el as HTMLElement).style.display = 'none';
    });
  });
};

// تشغيل الإزالة عند التحميل
setTimeout(removeWatermark, 100);
setTimeout(removeWatermark, 500);
setTimeout(removeWatermark, 1000);

// مراقبة التغييرات في DOM
const observer = new MutationObserver(() => {
  removeWatermark();
});

observer.observe(document.body, {
  childList: true,
  subtree: true
});

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <ErrorBoundary>
      <App />
    </ErrorBoundary>
  </StrictMode>,
)
