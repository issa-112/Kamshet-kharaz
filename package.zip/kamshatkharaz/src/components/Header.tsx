import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { ShoppingCart, Menu, X } from 'lucide-react';
import { useCart } from '../contexts/CartContext';
import { supabase } from '../lib/supabase';

export function Header() {
  const { getTotalItems } = useCart();
  const [siteName, setSiteName] = useState('كمشة خرز');
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  useEffect(() => {
    const fetchSiteName = async () => {
      const { data } = await supabase
        .from('content')
        .select('value')
        .eq('key', 'site_name')
        .maybeSingle();
      
      if (data) {
        setSiteName(data.value);
      }
    };
    fetchSiteName();
  }, []);

  return (
    <header className="bg-gradient-to-r from-beige-100 to-rose-100 shadow-md sticky top-0 z-50">
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <Link to="/" className="flex items-center space-x-3 space-x-reverse">
            <div className="w-12 h-12 bg-gradient-to-br from-gold-200 to-rose-200 rounded-full flex items-center justify-center shadow-lg">
              <span className="text-2xl">✨</span>
            </div>
            <h1 className="text-2xl md:text-3xl font-bold text-gold-300 font-arabic">
              {siteName}
            </h1>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-6 space-x-reverse font-arabic">
            <Link to="/" className="text-gray-700 hover:text-gold-300 transition-colors text-lg">
              الرئيسية
            </Link>
            <Link to="/products" className="text-gray-700 hover:text-gold-300 transition-colors text-lg">
              المنتجات
            </Link>
            <Link to="/about" className="text-gray-700 hover:text-gold-300 transition-colors text-lg">
              حولنا
            </Link>
            <Link to="/contact" className="text-gray-700 hover:text-gold-300 transition-colors text-lg">
              تواصل معنا
            </Link>
            <Link to="/cart" className="relative">
              <ShoppingCart className="w-6 h-6 text-gray-700 hover:text-gold-300 transition-colors" />
              {getTotalItems() > 0 && (
                <span className="absolute -top-2 -right-2 bg-rose-200 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
                  {getTotalItems()}
                </span>
              )}
            </Link>
          </nav>

          {/* Mobile Menu Button */}
          <button
            className="md:hidden text-gray-700"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
          >
            {isMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>

        {/* Mobile Navigation */}
        {isMenuOpen && (
          <nav className="md:hidden mt-4 pb-4 space-y-3 font-arabic">
            <Link to="/" className="block text-gray-700 hover:text-gold-300 transition-colors text-lg" onClick={() => setIsMenuOpen(false)}>
              الرئيسية
            </Link>
            <Link to="/products" className="block text-gray-700 hover:text-gold-300 transition-colors text-lg" onClick={() => setIsMenuOpen(false)}>
              المنتجات
            </Link>
            <Link to="/about" className="block text-gray-700 hover:text-gold-300 transition-colors text-lg" onClick={() => setIsMenuOpen(false)}>
              حولنا
            </Link>
            <Link to="/contact" className="block text-gray-700 hover:text-gold-300 transition-colors text-lg" onClick={() => setIsMenuOpen(false)}>
              تواصل معنا
            </Link>
            <Link to="/cart" className="flex items-center space-x-2 space-x-reverse text-gray-700 hover:text-gold-300 transition-colors text-lg" onClick={() => setIsMenuOpen(false)}>
              <ShoppingCart className="w-5 h-5" />
              <span>السلة ({getTotalItems()})</span>
            </Link>
          </nav>
        )}
      </div>
    </header>
  );
}
