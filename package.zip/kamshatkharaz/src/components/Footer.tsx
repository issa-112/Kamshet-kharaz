import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '../lib/supabase';

export function Footer() {
  const [footerText, setFooterText] = useState('جميع الحقوق محفوظة © 2025 كمشة خرز');
  const navigate = useNavigate();

  useEffect(() => {
    const fetchFooterText = async () => {
      const { data } = await supabase
        .from('content')
        .select('value')
        .eq('key', 'footer_text')
        .maybeSingle();
      
      if (data) {
        setFooterText(data.value);
      }
    };
    fetchFooterText();
  }, []);

  const handleFooterClick = () => {
    navigate('/admin/login');
  };

  return (
    <footer className="bg-gradient-to-r from-beige-100 to-rose-100 mt-16">
      <div className="container mx-auto px-4 py-8">
        <div className="text-center">
          <p 
            className="text-gray-600 font-arabic cursor-pointer hover:text-gold-300 transition-colors"
            onClick={handleFooterClick}
          >
            {footerText}
          </p>
        </div>
      </div>
    </footer>
  );
}
