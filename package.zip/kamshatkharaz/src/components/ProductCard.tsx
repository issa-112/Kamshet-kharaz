import React from 'react';
import { Product } from '../lib/supabase';
import { useCart } from '../contexts/CartContext';
import { ShoppingCart } from 'lucide-react';

interface ProductCardProps {
  product: Product;
}

export function ProductCard({ product }: ProductCardProps) {
  const { addToCart } = useCart();

  return (
    <div className="bg-white rounded-2xl shadow-md hover:shadow-xl transition-all duration-300 overflow-hidden group">
      <div className="relative overflow-hidden aspect-square">
        <img
          src={product.image_url}
          alt={product.name}
          className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
        />
        {product.is_featured && (
          <div className="absolute top-3 right-3 bg-gold-200 text-white px-3 py-1 rounded-full text-sm font-arabic">
            مميز
          </div>
        )}
      </div>
      <div className="p-5">
        <h3 className="text-xl font-bold text-gray-800 mb-2 font-arabic">{product.name}</h3>
        <p className="text-gray-600 text-sm mb-4 font-arabic line-clamp-2">{product.description}</p>
        <div className="flex items-center justify-between">
          <span className="text-2xl font-bold text-gold-300 font-arabic">{product.price.toFixed(2)} ل.س</span>
          <button
            onClick={() => addToCart(product)}
            className="bg-gradient-to-r from-rose-200 to-rose-300 text-white px-4 py-2 rounded-full hover:from-rose-300 hover:to-rose-200 transition-all duration-300 flex items-center space-x-2 space-x-reverse font-arabic shadow-md hover:shadow-lg"
          >
            <ShoppingCart className="w-4 h-4" />
            <span>إضافة</span>
          </button>
        </div>
      </div>
    </div>
  );
}
