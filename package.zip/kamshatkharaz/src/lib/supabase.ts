import { createClient } from '@supabase/supabase-js'

const supabaseUrl = "https://kohrzlpyklfcftnaulhd.supabase.co";
const supabaseAnonKey = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImtvaHJ6bHB5a2xmY2Z0bmF1bGhkIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjAzNjk5NTEsImV4cCI6MjA3NTk0NTk1MX0.n9kiaPek--nKiSewiZM6Z-v6Rsn504LRR2-He4MxDLQ";

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export interface Category {
  id: number;
  name: string;
  emoji: string;
  created_at: string;
}

export interface Product {
  id: number;
  name: string;
  description: string;
  price: number;
  image_url: string;
  category_id: number;
  is_featured: boolean;
  created_at: string;
}

export interface CartItem {
  product: Product;
  quantity: number;
}

export interface Order {
  id: number;
  customer_name: string;
  products_json: any;
  total_price: number;
  order_date: string;
  status: string;
}

export interface ContentItem {
  id: number;
  key: string;
  value: string;
  updated_at: string;
}

export interface Visitor {
  id: number;
  visit_date: string;
  ip_address?: string;
  created_at: string;
}
