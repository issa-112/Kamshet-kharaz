import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase, Product, Category, Order, Visitor, ContentItem } from '../../lib/supabase';
import toast from 'react-hot-toast';
import { LogOut, Package, Tag, FileText, TrendingUp, Plus, Edit, Trash2, Save, X, Upload } from 'lucide-react';

export function AdminDashboard() {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState('products');
  const [products, setProducts] = useState<Product[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);
  const [content, setContent] = useState<ContentItem[]>([]);
  const [visitors, setVisitors] = useState<Visitor[]>([]);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [editingCategory, setEditingCategory] = useState<Category | null>(null);
  const [editingContent, setEditingContent] = useState<ContentItem | null>(null);
  const [showAddProduct, setShowAddProduct] = useState(false);
  const [showAddCategory, setShowAddCategory] = useState(false);
  const [uploadingImage, setUploadingImage] = useState(false);

  useEffect(() => {
    const admin = localStorage.getItem('admin');
    if (!admin) {
      navigate('/admin/login');
      return;
    }
    fetchData();
  }, [navigate]);

  const fetchData = async () => {
    const { data: productsData } = await supabase.from('products').select('*').order('created_at', { ascending: false });
    const { data: categoriesData } = await supabase.from('categories').select('*');
    const { data: ordersData } = await supabase.from('orders').select('*').order('order_date', { ascending: false });
    const { data: contentData } = await supabase.from('content').select('*');
    const { data: visitorsData } = await supabase.from('visitors').select('*');

    if (productsData) setProducts(productsData);
    if (categoriesData) setCategories(categoriesData);
    if (ordersData) setOrders(ordersData);
    if (contentData) setContent(contentData);
    if (visitorsData) setVisitors(visitorsData);
  };

  const handleLogout = () => {
    localStorage.removeItem('admin');
    toast.success('تم تسجيل الخروج بنجاح');
    navigate('/');
  };

  const handleImageUpload = async (file: File): Promise<string> => {
    setUploadingImage(true);
    try {
      const reader = new FileReader();
      return new Promise((resolve, reject) => {
        reader.onloadend = async () => {
          try {
            const base64Data = reader.result as string;
            const fileName = `${Date.now()}-${file.name}`;

            const { data, error } = await supabase.functions.invoke('upload-product-image', {
              body: {
                imageData: base64Data,
                fileName
              }
            });

            if (error) throw error;
            setUploadingImage(false);
            toast.success('تم رفع الصورة بنجاح');
            resolve(data.data.publicUrl);
          } catch (err) {
            setUploadingImage(false);
            toast.error('فشل رفع الصورة');
            reject(err);
          }
        };
        reader.readAsDataURL(file);
      });
    } catch (error) {
      setUploadingImage(false);
      toast.error('فشل رفع الصورة');
      throw error;
    }
  };

  const handleAddProduct = async (formData: any) => {
    const { error } = await supabase.from('products').insert([formData]);
    if (error) {
      toast.error('فشل إضافة المنتج');
    } else {
      toast.success('تم إضافة المنتج بنجاح');
      setShowAddProduct(false);
      fetchData();
    }
  };

  const handleUpdateProduct = async (id: number, formData: any) => {
    const { error } = await supabase.from('products').update(formData).eq('id', id);
    if (error) {
      toast.error('فشل تحديث المنتج');
    } else {
      toast.success('تم تحديث المنتج بنجاح');
      setEditingProduct(null);
      fetchData();
    }
  };

  const handleDeleteProduct = async (id: number) => {
    if (confirm('هل أنت متأكد من حذف هذا المنتج؟')) {
      const { error } = await supabase.from('products').delete().eq('id', id);
      if (error) {
        toast.error('فشل حذف المنتج');
      } else {
        toast.success('تم حذف المنتج بنجاح');
        fetchData();
      }
    }
  };

  const handleAddCategory = async (formData: any) => {
    const { error } = await supabase.from('categories').insert([formData]);
    if (error) {
      toast.error('فشل إضافة الفئة');
    } else {
      toast.success('تم إضافة الفئة بنجاح');
      setShowAddCategory(false);
      fetchData();
    }
  };

  const handleUpdateCategory = async (id: number, formData: any) => {
    const { error } = await supabase.from('categories').update(formData).eq('id', id);
    if (error) {
      toast.error('فشل تحديث الفئة');
    } else {
      toast.success('تم تحديث الفئة بنجاح');
      setEditingCategory(null);
      fetchData();
    }
  };

  const handleDeleteCategory = async (id: number) => {
    if (confirm('هل أنت متأكد من حذف هذه الفئة؟')) {
      const { error } = await supabase.from('categories').delete().eq('id', id);
      if (error) {
        toast.error('فشل حذف الفئة');
      } else {
        toast.success('تم حذف الفئة بنجاح');
        fetchData();
      }
    }
  };

  const handleUpdateContent = async (id: number, value: string) => {
    const { error } = await supabase.from('content').update({ value, updated_at: new Date().toISOString() }).eq('id', id);
    if (error) {
      toast.error('فشل تحديث المحتوى');
    } else {
      toast.success('تم تحديث المحتوى بنجاح');
      setEditingContent(null);
      fetchData();
    }
  };

  // Statistics
  const today = new Date().toISOString().split('T')[0];
  const thisMonth = new Date().toISOString().slice(0, 7);
  const todayVisitors = visitors.filter(v => v.visit_date === today).length;
  const monthVisitors = visitors.filter(v => v.visit_date.startsWith(thisMonth)).length;
  const todayOrders = orders.filter(o => o.order_date.startsWith(today)).length;
  const monthOrders = orders.filter(o => o.order_date.startsWith(thisMonth)).length;

  return (
    <div className="min-h-screen bg-beige-50">
      {/* Header */}
      <div className="bg-gradient-to-r from-beige-100 to-rose-100 shadow-md">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <h1 className="text-2xl font-bold text-gold-300 font-arabic">لوحة التحكم</h1>
          <button
            onClick={handleLogout}
            className="flex items-center space-x-2 space-x-reverse bg-red-500 text-white px-4 py-2 rounded-lg hover:bg-red-600 transition-colors font-arabic"
          >
            <LogOut className="w-4 h-4" />
            <span>تسجيل خروج</span>
          </button>
        </div>
      </div>

      {/* Tabs */}
      <div className="bg-white shadow-sm">
        <div className="container mx-auto px-4">
          <div className="flex space-x-4 space-x-reverse overflow-x-auto">
            {[{id: 'products', label: 'المنتجات', icon: Package}, {id: 'categories', label: 'الفئات', icon: Tag}, {id: 'content', label: 'المحتوى', icon: FileText}, {id: 'stats', label: 'الإحصائيات', icon: TrendingUp}].map(tab => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center space-x-2 space-x-reverse px-6 py-4 font-arabic border-b-2 transition-colors ${activeTab === tab.id ? 'border-rose-300 text-rose-300' : 'border-transparent text-gray-600 hover:text-rose-300'}`}
              >
                <tab.icon className="w-5 h-5" />
                <span>{tab.label}</span>
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="container mx-auto px-4 py-8">
        {/* Products Tab */}
        {activeTab === 'products' && (
          <ProductsTab
            products={products}
            categories={categories}
            editingProduct={editingProduct}
            setEditingProduct={setEditingProduct}
            showAddProduct={showAddProduct}
            setShowAddProduct={setShowAddProduct}
            handleAddProduct={handleAddProduct}
            handleUpdateProduct={handleUpdateProduct}
            handleDeleteProduct={handleDeleteProduct}
            handleImageUpload={handleImageUpload}
            uploadingImage={uploadingImage}
          />
        )}

        {/* Categories Tab */}
        {activeTab === 'categories' && (
          <CategoriesTab
            categories={categories}
            editingCategory={editingCategory}
            setEditingCategory={setEditingCategory}
            showAddCategory={showAddCategory}
            setShowAddCategory={setShowAddCategory}
            handleAddCategory={handleAddCategory}
            handleUpdateCategory={handleUpdateCategory}
            handleDeleteCategory={handleDeleteCategory}
          />
        )}

        {/* Content Tab */}
        {activeTab === 'content' && (
          <ContentTab
            content={content}
            editingContent={editingContent}
            setEditingContent={setEditingContent}
            handleUpdateContent={handleUpdateContent}
          />
        )}

        {/* Stats Tab */}
        {activeTab === 'stats' && (
          <StatsTab
            todayVisitors={todayVisitors}
            monthVisitors={monthVisitors}
            todayOrders={todayOrders}
            monthOrders={monthOrders}
            orders={orders}
            visitors={visitors}
          />
        )}
      </div>
    </div>
  );
}

// Sub-components will be defined separately
function ProductsTab({ products, categories, editingProduct, setEditingProduct, showAddProduct, setShowAddProduct, handleAddProduct, handleUpdateProduct, handleDeleteProduct, handleImageUpload, uploadingImage }: any) {
  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold text-gray-800 font-arabic">إدارة المنتجات</h2>
        <button onClick={() => setShowAddProduct(true)} className="flex items-center space-x-2 space-x-reverse bg-gradient-to-r from-rose-200 to-rose-300 text-white px-4 py-2 rounded-lg hover:shadow-lg transition-all font-arabic">
          <Plus className="w-4 h-4" />
          <span>إضافة منتج</span>
        </button>
      </div>

      {/* Product Form - Will continue in next part */}
      {(showAddProduct || editingProduct) && (
        <ProductForm
          product={editingProduct}
          categories={categories}
          onSubmit={(data: any) => editingProduct ? handleUpdateProduct(editingProduct.id, data) : handleAddProduct(data)}
          onCancel={() => { setShowAddProduct(false); setEditingProduct(null); }}
          handleImageUpload={handleImageUpload}
          uploadingImage={uploadingImage}
        />
      )}

      {/* Products List */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {products.map((product: Product) => (
          <div key={product.id} className="bg-white rounded-lg shadow-md p-4">
            <img src={product.image_url} alt={product.name} className="w-full h-48 object-cover rounded-lg mb-4" />
            <h3 className="text-lg font-bold text-gray-800 mb-2 font-arabic">{product.name}</h3>
            <p className="text-gray-600 text-sm mb-2 font-arabic line-clamp-2">{product.description}</p>
            <p className="text-gold-300 font-bold mb-4 font-arabic">{product.price.toFixed(2)} ل.س</p>
            <div className="flex space-x-2 space-x-reverse">
              <button onClick={() => setEditingProduct(product)} className="flex-1 bg-blue-500 text-white px-3 py-2 rounded-lg hover:bg-blue-600 transition-colors flex items-center justify-center space-x-1 space-x-reverse font-arabic">
                <Edit className="w-4 h-4" />
                <span>تعديل</span>
              </button>
              <button onClick={() => handleDeleteProduct(product.id)} className="flex-1 bg-red-500 text-white px-3 py-2 rounded-lg hover:bg-red-600 transition-colors flex items-center justify-center space-x-1 space-x-reverse font-arabic">
                <Trash2 className="w-4 h-4" />
                <span>حذف</span>
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function ProductForm({ product, categories, onSubmit, onCancel, handleImageUpload, uploadingImage }: any) {
  const [formData, setFormData] = useState({
    name: product?.name || '',
    description: product?.description || '',
    price: product?.price || 0,
    image_url: product?.image_url || '',
    category_id: product?.category_id || categories[0]?.id || 0,
    is_featured: product?.is_featured || false,
  });

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const imageUrl = await handleImageUpload(file);
      setFormData({ ...formData, image_url: imageUrl });
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-lg p-6 mb-6">
      <h3 className="text-xl font-bold text-gray-800 mb-4 font-arabic">{product ? 'تعديل المنتج' : 'إضافة منتج جديد'}</h3>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <label className="block text-gray-700 font-arabic mb-2">الاسم</label>
          <input type="text" value={formData.name} onChange={(e) => setFormData({...formData, name: e.target.value})} className="w-full px-4 py-2 border rounded-lg text-right font-arabic" />
        </div>
        <div>
          <label className="block text-gray-700 font-arabic mb-2">السعر</label>
          <input type="number" value={formData.price} onChange={(e) => setFormData({...formData, price: parseFloat(e.target.value)})} className="w-full px-4 py-2 border rounded-lg text-right font-arabic" />
        </div>
        <div className="md:col-span-2">
          <label className="block text-gray-700 font-arabic mb-2">الوصف</label>
          <textarea value={formData.description} onChange={(e) => setFormData({...formData, description: e.target.value})} className="w-full px-4 py-2 border rounded-lg text-right font-arabic" rows={3} />
        </div>
        <div>
          <label className="block text-gray-700 font-arabic mb-2">الفئة</label>
          <select value={formData.category_id} onChange={(e) => setFormData({...formData, category_id: parseInt(e.target.value)})} className="w-full px-4 py-2 border rounded-lg text-right font-arabic">
            {categories.map((cat: Category) => <option key={cat.id} value={cat.id}>{cat.name}</option>)}
          </select>
        </div>
        <div>
          <label className="block text-gray-700 font-arabic mb-2">صورة المنتج</label>
          <input type="file" accept="image/*" onChange={handleFileChange} className="w-full px-4 py-2 border rounded-lg" disabled={uploadingImage} />
          {uploadingImage && <p className="text-sm text-gray-600 mt-2 font-arabic">جاري رفع الصورة...</p>}
        </div>
        <div className="flex items-center">
          <label className="flex items-center space-x-2 space-x-reverse cursor-pointer font-arabic">
            <input type="checkbox" checked={formData.is_featured} onChange={(e) => setFormData({...formData, is_featured: e.target.checked})} className="w-4 h-4" />
            <span>منتج مميز</span>
          </label>
        </div>
      </div>
      {formData.image_url && <img src={formData.image_url} alt="Preview" className="w-32 h-32 object-cover rounded-lg mt-4" />}
      <div className="flex space-x-4 space-x-reverse mt-6">
        <button onClick={() => onSubmit(formData)} className="flex-1 bg-gradient-to-r from-rose-200 to-rose-300 text-white px-4 py-2 rounded-lg hover:shadow-lg transition-all font-arabic flex items-center justify-center space-x-2 space-x-reverse">
          <Save className="w-4 h-4" />
          <span>حفظ</span>
        </button>
        <button onClick={onCancel} className="flex-1 bg-gray-300 text-gray-700 px-4 py-2 rounded-lg hover:bg-gray-400 transition-colors font-arabic flex items-center justify-center space-x-2 space-x-reverse">
          <X className="w-4 h-4" />
          <span>إلغاء</span>
        </button>
      </div>
    </div>
  );
}

function CategoriesTab({ categories, editingCategory, setEditingCategory, showAddCategory, setShowAddCategory, handleAddCategory, handleUpdateCategory, handleDeleteCategory }: any) {
  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold text-gray-800 font-arabic">إدارة الفئات</h2>
        <button onClick={() => setShowAddCategory(true)} className="flex items-center space-x-2 space-x-reverse bg-gradient-to-r from-rose-200 to-rose-300 text-white px-4 py-2 rounded-lg hover:shadow-lg transition-all font-arabic">
          <Plus className="w-4 h-4" />
          <span>إضافة فئة</span>
        </button>
      </div>

      {(showAddCategory || editingCategory) && (
        <CategoryForm
          category={editingCategory}
          onSubmit={(data: any) => editingCategory ? handleUpdateCategory(editingCategory.id, data) : handleAddCategory(data)}
          onCancel={() => { setShowAddCategory(false); setEditingCategory(null); }}
        />
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {categories.map((category: Category) => (
          <div key={category.id} className="bg-white rounded-lg shadow-md p-6 text-center">
            <div className="text-4xl mb-3">{category.emoji}</div>
            <h3 className="text-lg font-bold text-gray-800 mb-4 font-arabic">{category.name}</h3>
            <div className="flex space-x-2 space-x-reverse">
              <button onClick={() => setEditingCategory(category)} className="flex-1 bg-blue-500 text-white px-3 py-2 rounded-lg hover:bg-blue-600 transition-colors font-arabic">تعديل</button>
              <button onClick={() => handleDeleteCategory(category.id)} className="flex-1 bg-red-500 text-white px-3 py-2 rounded-lg hover:bg-red-600 transition-colors font-arabic">حذف</button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function CategoryForm({ category, onSubmit, onCancel }: any) {
  const [formData, setFormData] = useState({
    name: category?.name || '',
    emoji: category?.emoji || '',
  });

  return (
    <div className="bg-white rounded-lg shadow-lg p-6 mb-6">
      <h3 className="text-xl font-bold text-gray-800 mb-4 font-arabic">{category ? 'تعديل الفئة' : 'إضافة فئة جديدة'}</h3>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <label className="block text-gray-700 font-arabic mb-2">الاسم</label>
          <input type="text" value={formData.name} onChange={(e) => setFormData({...formData, name: e.target.value})} className="w-full px-4 py-2 border rounded-lg text-right font-arabic" />
        </div>
        <div>
          <label className="block text-gray-700 font-arabic mb-2">الرمز</label>
          <input type="text" value={formData.emoji} onChange={(e) => setFormData({...formData, emoji: e.target.value})} className="w-full px-4 py-2 border rounded-lg text-center" placeholder="✨" />
        </div>
      </div>
      <div className="flex space-x-4 space-x-reverse mt-6">
        <button onClick={() => onSubmit(formData)} className="flex-1 bg-gradient-to-r from-rose-200 to-rose-300 text-white px-4 py-2 rounded-lg hover:shadow-lg transition-all font-arabic">حفظ</button>
        <button onClick={onCancel} className="flex-1 bg-gray-300 text-gray-700 px-4 py-2 rounded-lg hover:bg-gray-400 transition-colors font-arabic">إلغاء</button>
      </div>
    </div>
  );
}

function ContentTab({ content, editingContent, setEditingContent, handleUpdateContent }: any) {
  const [editValue, setEditValue] = useState('');

  const getContentLabel = (key: string) => {
    const labels: any = {
      'site_name': 'اسم الموقع',
      'about_us': 'نص صفحة حولنا',
      'whatsapp_number': 'رقم الواتساب',
      'facebook_url': 'رابط فيسبوك',
      'location': 'الموقع الجغرافي',
      'footer_text': 'نص الفوتر',
    };
    return labels[key] || key;
  };

  return (
    <div>
      <h2 className="text-2xl font-bold text-gray-800 mb-6 font-arabic">إدارة المحتوى</h2>
      <div className="space-y-4">
        {content.map((item: ContentItem) => (
          <div key={item.id} className="bg-white rounded-lg shadow-md p-6">
            <h3 className="text-lg font-bold text-gray-800 mb-3 font-arabic">{getContentLabel(item.key)}</h3>
            {editingContent?.id === item.id ? (
              <div>
                <textarea
                  value={editValue}
                  onChange={(e) => setEditValue(e.target.value)}
                  className="w-full px-4 py-2 border rounded-lg text-right font-arabic mb-4"
                  rows={item.key === 'about_us' ? 6 : 2}
                />
                <div className="flex space-x-4 space-x-reverse">
                  <button onClick={() => { handleUpdateContent(item.id, editValue); }} className="bg-gradient-to-r from-rose-200 to-rose-300 text-white px-4 py-2 rounded-lg hover:shadow-lg transition-all font-arabic">حفظ</button>
                  <button onClick={() => setEditingContent(null)} className="bg-gray-300 text-gray-700 px-4 py-2 rounded-lg hover:bg-gray-400 transition-colors font-arabic">إلغاء</button>
                </div>
              </div>
            ) : (
              <div>
                <p className="text-gray-700 mb-4 font-arabic whitespace-pre-wrap">{item.value}</p>
                <button onClick={() => { setEditingContent(item); setEditValue(item.value); }} className="bg-blue-500 text-white px-4 py-2 rounded-lg hover:bg-blue-600 transition-colors font-arabic">تعديل</button>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}

function StatsTab({ todayVisitors, monthVisitors, todayOrders, monthOrders, orders, visitors }: any) {
  return (
    <div>
      <h2 className="text-2xl font-bold text-gray-800 mb-6 font-arabic">الإحصائيات</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <div className="bg-white rounded-lg shadow-md p-6">
          <h3 className="text-gray-600 font-arabic mb-2">زوار اليوم</h3>
          <p className="text-4xl font-bold text-gold-300">{todayVisitors}</p>
        </div>
        <div className="bg-white rounded-lg shadow-md p-6">
          <h3 className="text-gray-600 font-arabic mb-2">زوار الشهر</h3>
          <p className="text-4xl font-bold text-gold-300">{monthVisitors}</p>
        </div>
        <div className="bg-white rounded-lg shadow-md p-6">
          <h3 className="text-gray-600 font-arabic mb-2">طلبات اليوم</h3>
          <p className="text-4xl font-bold text-rose-300">{todayOrders}</p>
        </div>
        <div className="bg-white rounded-lg shadow-md p-6">
          <h3 className="text-gray-600 font-arabic mb-2">طلبات الشهر</h3>
          <p className="text-4xl font-bold text-rose-300">{monthOrders}</p>
        </div>
      </div>

      {/* Recent Orders */}
      <div className="bg-white rounded-lg shadow-md p-6">
        <h3 className="text-xl font-bold text-gray-800 mb-4 font-arabic">آخر الطلبات</h3>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b">
                <th className="text-right py-3 px-4 font-arabic">الاسم</th>
                <th className="text-right py-3 px-4 font-arabic">الإجمالي</th>
                <th className="text-right py-3 px-4 font-arabic">التاريخ</th>
              </tr>
            </thead>
            <tbody>
              {orders.slice(0, 10).map((order: Order) => (
                <tr key={order.id} className="border-b">
                  <td className="py-3 px-4 font-arabic">{order.customer_name}</td>
                  <td className="py-3 px-4 font-arabic">{order.total_price.toFixed(2)} ل.س</td>
                  <td className="py-3 px-4 font-arabic">{new Date(order.order_date).toLocaleDateString('ar-SY')}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
