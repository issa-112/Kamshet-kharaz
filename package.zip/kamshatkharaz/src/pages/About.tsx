import React, { useEffect, useState } from 'react';
import { supabase } from '../lib/supabase';

export function About() {
  const [aboutText, setAboutText] = useState('');

  useEffect(() => {
    const fetchAboutText = async () => {
      const { data } = await supabase
        .from('content')
        .select('value')
        .eq('key', 'about_us')
        .maybeSingle();
      
      if (data) {
        setAboutText(data.value);
      }
    };
    fetchAboutText();
  }, []);

  return (
    <div className="min-h-screen py-12 bg-beige-50">
      <div className="container mx-auto px-4 max-w-4xl">
        <h1 className="text-4xl md:text-5xl font-bold text-center text-gray-800 mb-12 font-arabic">
          حولنا
        </h1>
        
        <div className="bg-white rounded-2xl shadow-lg p-8 md:p-12">
          <div className="flex justify-center mb-8">
            <div className="w-20 h-20 bg-gradient-to-br from-gold-200 to-rose-200 rounded-full flex items-center justify-center shadow-lg">
              <span className="text-4xl">✨</span>
            </div>
          </div>
          
          <div className="prose prose-lg mx-auto text-right font-arabic">
            <p className="text-gray-700 text-xl leading-relaxed whitespace-pre-wrap">
              {aboutText}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
