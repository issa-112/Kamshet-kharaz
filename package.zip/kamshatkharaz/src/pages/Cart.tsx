import React, { useState } from 'react';
import { useCart } from '../contexts/CartContext';
import { Trash2, Plus, Minus, ShoppingBag } from 'lucide-react';
import { supabase } from '../lib/supabase';
import toast from 'react-hot-toast';

export function Cart() {
  const { cart, removeFromCart, updateQuantity, clearCart, getTotalPrice } = useCart();
  const [customerName, setCustomerName] = useState('');
  const [showNameInput, setShowNameInput] = useState(false);
  const [whatsappNumber, setWhatsappNumber] = useState('0945400450');

  React.useEffect(() => {
    const fetchWhatsappNumber = async () => {
      const { data } = await supabase
        .from('content')
        .select('value')
        .eq('key', 'whatsapp_number')
        .maybeSingle();
      
      if (data) {
        setWhatsappNumber(data.value);
      }
    };
    fetchWhatsappNumber();
  }, []);

  const handleCheckout = () => {
    if (cart.length === 0) {
      toast.error('السلة فارغة');
      return;
    }
    setShowNameInput(true);
  };

  const handleSendWhatsApp = async () => {
    if (!customerName.trim()) {
      toast.error('الرجاء إدخال اسمك');
      return;
    }

    // حفظ الطلب في قاعدة البيانات
    const productsJson = cart.map(item => ({
      product_id: item.product.id,
      product_name: item.product.name,
      quantity: item.quantity,
      price: item.product.price,
    }));

    await supabase.from('orders').insert([{
      customer_name: customerName,
      products_json: productsJson,
      total_price: getTotalPrice(),
      status: 'pending',
    }]);

    // إعداد رسالة واتساب
    let message = `مرحباً\nالاسم: ${customerName}\n\nطلب جديد:\n\n`;
    
    cart.forEach(item => {
      message += `- ${item.product.name}\n  الكمية: ${item.quantity}\n  السعر: ${(item.product.price * item.quantity).toFixed(2)} ل.س\n\n`;
    });
    
    message += `الإجمالي: ${getTotalPrice().toFixed(2)} ل.س`;

    const encodedMessage = encodeURIComponent(message);
    const phoneNumber = whatsappNumber.replace(/[^0-9]/g, '');
    const whatsappUrl = `https://wa.me/${phoneNumber}?text=${encodedMessage}`;

    // فتح واتساب
    window.open(whatsappUrl, '_blank');

    // تفريغ السلة
    clearCart();
    setShowNameInput(false);
    setCustomerName('');
    toast.success('تم إرسال الطلب عبر واتساب');
  };

  if (cart.length === 0 && !showNameInput) {
    return (
      <div className="min-h-screen py-12 bg-beige-50">
        <div className="container mx-auto px-4">
          <div className="max-w-2xl mx-auto text-center py-20">
            <ShoppingBag className="w-24 h-24 mx-auto text-gray-300 mb-6" />
            <h2 className="text-3xl font-bold text-gray-800 mb-4 font-arabic">
              السلة فارغة
            </h2>
            <p className="text-gray-600 font-arabic mb-8">
              لم تقم بإضافة أي منتجات بعد
            </p>
            <a
              href="/products"
              className="inline-block bg-gradient-to-r from-rose-200 to-rose-300 text-white px-8 py-3 rounded-full font-arabic hover:from-rose-300 hover:to-rose-200 transition-all duration-300 shadow-md"
            >
              تصفح المنتجات
            </a>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen py-12 bg-beige-50">
      <div className="container mx-auto px-4">
        <h1 className="text-4xl md:text-5xl font-bold text-center text-gray-800 mb-12 font-arabic">
          سلة التسوق
        </h1>

        <div className="max-w-4xl mx-auto">
          {/* Cart Items */}
          <div className="bg-white rounded-2xl shadow-lg p-6 mb-8">
            {cart.map(item => (
              <div key={item.product.id} className="flex items-center space-x-4 space-x-reverse py-4 border-b last:border-b-0">
                <img
                  src={item.product.image_url}
                  alt={item.product.name}
                  className="w-20 h-20 object-cover rounded-lg"
                />
                <div className="flex-1">
                  <h3 className="text-lg font-bold text-gray-800 font-arabic">{item.product.name}</h3>
                  <p className="text-gold-300 font-bold font-arabic">{item.product.price.toFixed(2)} ل.س</p>
                </div>
                <div className="flex items-center space-x-3 space-x-reverse">
                  <button
                    onClick={() => updateQuantity(item.product.id, item.quantity - 1)}
                    className="w-8 h-8 bg-gray-200 rounded-full flex items-center justify-center hover:bg-gray-300 transition-colors"
                  >
                    <Minus className="w-4 h-4" />
                  </button>
                  <span className="text-lg font-bold w-8 text-center">{item.quantity}</span>
                  <button
                    onClick={() => updateQuantity(item.product.id, item.quantity + 1)}
                    className="w-8 h-8 bg-gray-200 rounded-full flex items-center justify-center hover:bg-gray-300 transition-colors"
                  >
                    <Plus className="w-4 h-4" />
                  </button>
                </div>
                <button
                  onClick={() => removeFromCart(item.product.id)}
                  className="text-red-500 hover:text-red-700 transition-colors"
                >
                  <Trash2 className="w-5 h-5" />
                </button>
              </div>
            ))}
          </div>

          {/* Total */}
          <div className="bg-white rounded-2xl shadow-lg p-6 mb-8">
            <div className="flex justify-between items-center text-2xl font-bold font-arabic">
              <span className="text-gray-800">الإجمالي:</span>
              <span className="text-gold-300">{getTotalPrice().toFixed(2)} ل.س</span>
            </div>
          </div>

          {/* Checkout */}
          {!showNameInput ? (
            <button
              onClick={handleCheckout}
              className="w-full bg-gradient-to-r from-rose-200 to-rose-300 text-white py-4 rounded-full text-xl font-bold font-arabic hover:from-rose-300 hover:to-rose-200 transition-all duration-300 shadow-lg hover:shadow-xl"
            >
              تأكيد الشراء
            </button>
          ) : (
            <div className="bg-white rounded-2xl shadow-lg p-6">
              <h2 className="text-2xl font-bold text-gray-800 mb-4 font-arabic">
                الرجاء إدخال اسمك
              </h2>
              <input
                type="text"
                value={customerName}
                onChange={(e) => setCustomerName(e.target.value)}
                placeholder="الاسم"
                className="w-full px-4 py-3 border border-gray-300 rounded-lg mb-4 text-right font-arabic focus:outline-none focus:ring-2 focus:ring-rose-200"
              />
              <button
                onClick={handleSendWhatsApp}
                className="w-full bg-green-500 text-white py-4 rounded-full text-xl font-bold font-arabic hover:bg-green-600 transition-all duration-300 shadow-lg hover:shadow-xl"
              >
                إرسال عبر واتساب
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
