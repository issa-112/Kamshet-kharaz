import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { supabase, Product, Category } from '../lib/supabase';
import { ProductCard } from '../components/ProductCard';
import { ArrowRight } from 'lucide-react';

export function Home() {
  const [featuredProducts, setFeaturedProducts] = useState<Product[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [siteName, setSiteName] = useState('كمشة خرز');

  useEffect(() => {
    // تسجيل زيارة
    const recordVisit = async () => {
      await supabase.from('visitors').insert([{
        visit_date: new Date().toISOString().split('T')[0],
      }]);
    };
    recordVisit();

    // جلب المنتجات المميزة
    const fetchFeaturedProducts = async () => {
      const { data } = await supabase
        .from('products')
        .select('*')
        .eq('is_featured', true)
        .limit(6);
      
      if (data) {
        setFeaturedProducts(data);
      }
    };

    // جلب الفئات
    const fetchCategories = async () => {
      const { data } = await supabase
        .from('categories')
        .select('*');
      
      if (data) {
        setCategories(data);
      }
    };

    // جلب اسم الموقع
    const fetchSiteName = async () => {
      const { data } = await supabase
        .from('content')
        .select('value')
        .eq('key', 'site_name')
        .maybeSingle();
      
      if (data) {
        setSiteName(data.value);
      }
    };

    fetchFeaturedProducts();
    fetchCategories();
    fetchSiteName();
  }, []);

  return (
    <div className="min-h-screen">
      {/* Hero Banner */}
      <section className="bg-gradient-to-br from-beige-100 via-rose-50 to-gold-50 py-20">
        <div className="container mx-auto px-4 text-center">
          <div className="mb-8">
            <div className="w-24 h-24 mx-auto bg-gradient-to-br from-gold-200 to-rose-200 rounded-full flex items-center justify-center shadow-xl mb-6">
              <span className="text-5xl">✨</span>
            </div>
          </div>
          <h1 className="text-5xl md:text-6xl font-bold text-gold-300 mb-6 font-arabic">
            {siteName}
          </h1>
          <p className="text-xl md:text-2xl text-gray-700 mb-8 font-arabic max-w-2xl mx-auto">
            منتجات يدوية فريدة من الصوف والكروشيه
          </p>
          <Link
            to="/products"
            className="inline-flex items-center space-x-2 space-x-reverse bg-gradient-to-r from-rose-200 to-rose-300 text-white px-8 py-4 rounded-full text-lg font-arabic hover:from-rose-300 hover:to-rose-200 transition-all duration-300 shadow-lg hover:shadow-xl"
          >
            <span>تصفح المنتجات</span>
            <ArrowRight className="w-5 h-5" />
          </Link>
        </div>
      </section>

      {/* Categories */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl md:text-4xl font-bold text-center text-gray-800 mb-12 font-arabic">
            الفئات
          </h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {categories.map((category) => (
              <Link
                key={category.id}
                to={`/products?category=${category.id}`}
                className="bg-gradient-to-br from-beige-50 to-rose-50 p-8 rounded-2xl text-center hover:shadow-xl transition-all duration-300 group"
              >
                <div className="text-5xl mb-4 group-hover:scale-110 transition-transform">
                  {category.emoji}
                </div>
                <h3 className="text-xl font-bold text-gray-800 font-arabic">
                  {category.name}
                </h3>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Featured Products */}
      {featuredProducts.length > 0 && (
        <section className="py-16 bg-beige-50">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl md:text-4xl font-bold text-center text-gray-800 mb-12 font-arabic">
              المنتجات المميزة
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {featuredProducts.map((product) => (
                <ProductCard key={product.id} product={product} />
              ))}
            </div>
            <div className="text-center mt-12">
              <Link
                to="/products"
                className="inline-flex items-center space-x-2 space-x-reverse bg-gradient-to-r from-gold-200 to-gold-300 text-white px-6 py-3 rounded-full font-arabic hover:from-gold-300 hover:to-gold-200 transition-all duration-300 shadow-md hover:shadow-lg"
              >
                <span>عرض المزيد</span>
                <ArrowRight className="w-4 h-4" />
              </Link>
            </div>
          </div>
        </section>
      )}
    </div>
  );
}
