import React, { useEffect, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { supabase, Product, Category } from '../lib/supabase';
import { ProductCard } from '../components/ProductCard';

export function Products() {
  const [products, setProducts] = useState<Product[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [selectedCategory, setSelectedCategory] = useState<number | null>(null);
  const [searchParams, setSearchParams] = useSearchParams();

  useEffect(() => {
    const categoryParam = searchParams.get('category');
    if (categoryParam) {
      setSelectedCategory(parseInt(categoryParam));
    }
  }, [searchParams]);

  useEffect(() => {
    const fetchCategories = async () => {
      const { data } = await supabase
        .from('categories')
        .select('*');
      
      if (data) {
        setCategories(data);
      }
    };
    fetchCategories();
  }, []);

  useEffect(() => {
    const fetchProducts = async () => {
      let query = supabase.from('products').select('*');
      
      if (selectedCategory) {
        query = query.eq('category_id', selectedCategory);
      }
      
      const { data } = await query.order('created_at', { ascending: false });
      
      if (data) {
        setProducts(data);
      }
    };
    fetchProducts();
  }, [selectedCategory]);

  const handleCategoryFilter = (categoryId: number | null) => {
    setSelectedCategory(categoryId);
    if (categoryId) {
      setSearchParams({ category: categoryId.toString() });
    } else {
      setSearchParams({});
    }
  };

  return (
    <div className="min-h-screen py-12 bg-beige-50">
      <div className="container mx-auto px-4">
        <h1 className="text-4xl md:text-5xl font-bold text-center text-gray-800 mb-12 font-arabic">
          منتجاتنا
        </h1>

        {/* Category Filter */}
        <div className="flex flex-wrap justify-center gap-4 mb-12">
          <button
            onClick={() => handleCategoryFilter(null)}
            className={`px-6 py-3 rounded-full font-arabic transition-all duration-300 shadow-md ${
              selectedCategory === null
                ? 'bg-gradient-to-r from-rose-200 to-rose-300 text-white'
                : 'bg-white text-gray-700 hover:shadow-lg'
            }`}
          >
            الكل
          </button>
          {categories.map((category) => (
            <button
              key={category.id}
              onClick={() => handleCategoryFilter(category.id)}
              className={`px-6 py-3 rounded-full font-arabic transition-all duration-300 shadow-md flex items-center space-x-2 space-x-reverse ${
                selectedCategory === category.id
                  ? 'bg-gradient-to-r from-rose-200 to-rose-300 text-white'
                  : 'bg-white text-gray-700 hover:shadow-lg'
              }`}
            >
              <span>{category.emoji}</span>
              <span>{category.name}</span>
            </button>
          ))}
        </div>

        {/* Products Grid */}
        {products.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
            {products.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        ) : (
          <div className="text-center py-20">
            <p className="text-2xl text-gray-600 font-arabic">
              لا توجد منتجات في هذه الفئة
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
