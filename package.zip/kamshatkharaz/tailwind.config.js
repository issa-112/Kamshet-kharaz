/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        beige: {
          50: '#FAF0E6',
          100: '#F5F5DC',
          200: '#EEE8D5',
          300: '#E5DCC5',
        },
        gold: {
          50: '#FFF9E6',
          100: '#F0C575',
          200: '#D4AF37',
          300: '#B8960F',
        },
        rose: {
          50: '#FFF5F7',
          100: '#FFE4E1',
          200: '#FFC0CB',
          300: '#FFB6C1',
        },
        softGray: {
          50: '#F8F8F8',
          100: '#E0E0E0',
          200: '#D0D0D0',
        },
      },
      fontFamily: {
        arabic: ['Tajawal', 'Cairo', 'sans-serif'],
      },
    },
  },
  plugins: [],
}
